# This script is part of the replication material for the manuscript "Measuring Terrorism"
# It produces the figures in the main manuscript plus two new csv files for use in 
# the Stata script "replication_tables.do", which accompanies this file.

library("tidyverse")
library("ggpubr")
library("patchwork")
library("ggplot2")
library("sur")
library("DiagrammeR")
library("SLIDE")
library("DataCombine")

setwd("D:/Dropbox/Jobb/RProjects/Neil and Thomas/review/replication_files")

NESSER <- read.csv("Nesser.csv", sep=",")
CREN <- read.csv("Crenshaw.csv", sep=",")
POICN <- read.csv("POICN.csv", sep=",")

# *** FIGURE 1: The terrorist attack implementation spectrum ***

#This code does not export the figure to a file. 
#It will display the figure in the R console, from where it can be saved in the desired format. 

grViz("

digraph Stages {

graph[layout = dot, rankdir = LR, fontsize = 16, fontname = 'Helvetica-bold']

subgraph cluster_1 {
		style=filled;
		color=lightblue;
		node [style=filled,color=white, fontsize = 13.5, fontname = 'Helvetica-bold'];
		box2 -> box4[penwidth = 2, weight = 3];
    box2 -> box3[penwidth = 1, style = dashed];
		label = 'SELECTION STAGE'; # font of this label determined by 'graph' above
      }
subgraph cluster_2 {
		style=filled;
		color=lightblue;
		node [style=filled,color=white, fontsize = 13.5, fontname = 'Helvetica-bold'];
		box5 -> box7[penwidth = 2, weight = 3];
		box5 -> box6[penwidth = 1, style = dashed]
		label = 'ATTRITION STAGE';
		}

node [fontsize = 13.5, fontname = 'Helvetica-bold']
      
box1 [label = 'Aspirations', shape = box, height = 2.2 width = 1.5, penwidth = 1, color = darkgrey]; 
box2 [label = 'SELECTION\n\nby terrorists based on\nperceived constraints', shape = oval, penwidth = 2, height = 2 width = 2.5];
box3 [label = 'Discarded\naspirations', shape = box, height = 2, width = 1.5]; 
box4 [label = 'Plots', shape = box, height = 2, width = 1.5, penwidth = 2]; 
box5 [label = 'ATTRITION\n\nby factors\nuncontrolled\nby terrorists', shape = oval, penwidth = 2, height = 2 width = 2.5];
box6 [label = 'Foiled plots', shape = box, height = 2, width = 1.5]; 
box7 [label = 'Attacks', shape = box, height = 2 width = 1.5, penwidth = 2]

box1 -> box2 [penwidth = 2]
box4 -> box5 [penwidth = 2]

}
")

# *** FIGURE 2: Bivariate correlations by units of analysis ***

#NESSER
NMONTHS <- read.csv("Nesser_CM.csv", sep=",")
YEARS <- NESSER %>%
  group_by(year) %>% 
  summarise(launched = sum(launched), all = sum(all))
COUNTRIES <- NESSER %>%
  group_by(country) %>%
  summarise(launched = sum(launched), all = sum(all))

#Nesser - by country
p1 <- ggplot(COUNTRIES, aes(launched, all)) +
  geom_jitter(colour = "magenta", size = 2, alpha = 0.3, width = 2) +
  ggtitle("Country (n=18)") +
  geom_smooth(method = lm, lty = 2, colour = "black", size = 0.5, se=FALSE) +
  xlab("Attacks") + ylab("Plots") +
  theme(axis.line = element_line(), panel.background = element_blank(), axis.title = element_text(size = (8)), plot.title = element_text(size = 8, face = "bold", hjust = 0.5), axis.text.x = element_blank(), axis.ticks.x = element_blank(), axis.text.y = element_blank(), axis.ticks.y = element_blank()) + 
  stat_cor(aes(label = ..r.label..), label.x.npc = 0.4, label.y.npc = "bottom", method = "pearson", cor.coef.name = "r", r.accuracy = 0.01, size = 5.5)

#Nesser - by year
p2 <- ggplot(YEARS, aes(launched, all)) +
  geom_jitter(colour = "magenta", size = 2, alpha = 0.3, width = 1) +
  ggtitle("Year (n=25)") +
  geom_smooth(method = lm, lty = 2, colour = "black", size = 0.5, se=FALSE) +
  xlab("Attacks") + ylab("Plots") +
  theme(axis.line = element_line(), panel.background = element_blank(), axis.title = element_text(size = (8)), plot.title = element_text(size = 8, face = "bold", hjust = 0.5), axis.text.x = element_blank(), axis.ticks.x = element_blank(), axis.text.y = element_blank(), axis.ticks.y = element_blank()) + 
  stat_cor(aes(label = ..r.label..), label.x.npc = 0.4, label.y.npc = "bottom", method = "pearson", cor.coef.name = "r", r.accuracy = 0.01, size = 5.5)

#Nesser - by country year
p3 <- ggplot(NESSER, aes(launched, all)) +
  geom_jitter(colour = "magenta", size = 2, alpha = 0.3, width = 1) +
  ggtitle("Country year (n=450)") +
  geom_smooth(method = lm, lty = 2, colour = "black", size = 0.5, se=FALSE) +
  xlab("Attacks") + ylab("Plots") +
  theme(axis.line = element_line(), panel.background = element_blank(), axis.title = element_text(size = (8)), plot.title = element_text(size = 8, face = "bold", hjust = 0.5), axis.text.x = element_blank(), axis.ticks.x = element_blank(), axis.text.y = element_blank(), axis.ticks.y = element_blank()) +
  stat_cor(aes(label = ..r.label..), label.x.npc = 0.37, label.y = 2.5, method = "pearson", cor.coef.name = "r", r.accuracy = 0.01, size = 5.5)

#Nesser - by country month
p4 <- ggplot(NMONTHS, aes(launched, all)) +
  geom_jitter(colour = "magenta", size = 2, alpha = 0.3, width = 0.5) +
  ggtitle("Country month (n=5400)") +
  geom_smooth(method = lm, lty = 2, colour = "black", size = 0.5, se=FALSE) +
  xlab("Attacks") + ylab("Plots") +
  theme(axis.line = element_line(), panel.background = element_blank(), axis.title = element_text(size = (8)), plot.title = element_text(size = 8, face = "bold", hjust = 0.5), axis.text.x = element_blank(), axis.ticks.x = element_blank(), axis.text.y = element_blank(), axis.ticks.y = element_blank()) +
  stat_cor(aes(label = ..r.label..,), label.x.npc = 0.35, label.y = 0.55, method = "pearson", cor.coef.name = "r", r.accuracy = 0.01, size = 5.5)

#Combining the above to row of figures
figA <- ggarrange(p1, p2, p3, p4, ncol = 4, nrow = 1, heights = c(0.5,0.5,0.5,0.5))
figA <- annotate_figure(figA, left = text_grob("Nesser     ", face = "bold", size = 11))

#CRENSHAW
CMONTHS <- read.csv("Crenshaw_CM.csv", sep=",")
COUNTRIES <- CREN %>%
  group_by(country) %>%
  summarise(launched = sum(launched), all = sum(all))
YEARS <- CREN %>%
  group_by(year) %>% 
  summarise(launched = sum(launched), all = sum(all))

#Crenshaw - by country
p5 <- ggplot(COUNTRIES, aes(launched, all)) +
  geom_jitter(colour = "dodgerblue", size = 2, alpha = 0.3, width = 2) +
  ggtitle("Country (n=21)") +
  geom_smooth(method = lm, lty = 2, colour = "black", size = 0.5, se=FALSE) +
  xlab("Attacks") + ylab("Plots") +
  theme(axis.line = element_line(), panel.background = element_blank(), axis.title = element_text(size = (8)), plot.title = element_text(size = 8, face = "bold", hjust = 0.5), axis.text.x = element_blank(), axis.ticks.x = element_blank(), axis.text.y = element_blank(), axis.ticks.y = element_blank()) +
  stat_cor(aes(label = ..r.label..), label.x.npc = 0.4, label.y.npc = "bottom", method = "pearson", cor.coef.name = "r", r.accuracy = 0.01, size = 5.5)

#Crenshaw - by year
p6 <- ggplot(YEARS, aes(launched, all)) +
  geom_jitter(colour = "dodgerblue", size = 2, alpha = 0.3, width = 1) +
  ggtitle("Year (n=24)") +
  geom_smooth(method = lm, lty = 2, colour = "black", size = 0.5, se=FALSE) +
  xlab("Attacks") + ylab("Plots") +
  theme(axis.line = element_line(), panel.background = element_blank(), axis.title = element_text(size = (8)), plot.title = element_text(size = 8, face = "bold", hjust = 0.5), axis.text.x = element_blank(), axis.ticks.x = element_blank(), axis.text.y = element_blank(), axis.ticks.y = element_blank()) +
  stat_cor(aes(label = ..r.label..), label.x.npc = 0.43, label.y.npc = "bottom", method = "pearson", cor.coef.name = "r", r.accuracy = 0.001, size = 5.5)

#Crenshaw - by country year
p7 <- ggplot(CREN, aes(launched, all)) +
  geom_jitter(colour = "dodgerblue", size = 2, alpha = 0.3, width = 1) +
  ggtitle("Country year (n=504)") +
  geom_smooth(method = lm, lty = 2, colour = "black", size = 0.5, se=FALSE) +
  xlab("Attacks") + ylab("Plots") +
  theme(axis.line = element_line(), panel.background = element_blank(), axis.title = element_text(size = (8)), plot.title = element_text(size = 8, face = "bold", hjust = 0.5), axis.text.x = element_blank(), axis.ticks.x = element_blank(), axis.text.y = element_blank(), axis.ticks.y = element_blank()) +
  stat_cor(aes(label = ..r.label..), label.x.npc = 0.38, label.y.npc = "bottom", method = "pearson", cor.coef.name = "r", r.accuracy = 0.0001, size = 5.5)

#Crenshaw by country months
p8 <- ggplot(CMONTHS, aes(launched, all)) +
  geom_jitter(colour = "dodgerblue", size = 2, alpha = 0.3, width = 0.5) +
  ggtitle("Country month (n=6346)") +
  geom_smooth(method = lm, lty = 2, colour = "black", size = 0.5, se=FALSE) +
  xlab("Attacks") + ylab("Plots") +
  theme(axis.line = element_line(), panel.background = element_blank(), axis.title = element_text(size = (8)), plot.title = element_text(size = 8, face = "bold", hjust = 0.5), axis.text.x = element_blank(), axis.ticks.x = element_blank(), axis.text.y = element_blank(), axis.ticks.y = element_blank()) +
  stat_cor(aes(label = ..r.label..), label.x.npc = 0.35, label.y.npc = 0.2, method = "pearson", cor.coef.name = "r", r.accuracy = 0.01, size = 5.5)

#Combining the above to row of figures
figB <- ggarrange(p5, p6, p7, p8, ncol = 4, nrow = 1)
figB <- annotate_figure(figB, left = text_grob("Crenshaw", face = "bold", size = 11))

#POICN
POICN$all <- POICN$launched + POICN$foiled
YEARS <- POICN %>%
  group_by(year) %>% 
  summarise(launched = sum(launched), all = sum(all))
COUNTRIES <- POICN %>%
  group_by(iso2c) %>%
  summarise(launched = sum(launched), all = sum(all))

#POICN - by country
p9 <- ggplot(COUNTRIES, aes(launched, all)) +
  geom_jitter(colour = "green", size = 2, alpha = 0.2, width = 2) +
  ggtitle("Country (n=217)") +
  geom_smooth(method = lm, lty = 2, colour = "black", size = 0.5, se=FALSE) +
  xlab("Attacks") +
  ylab("Plots") +
  theme(axis.line = element_line(), panel.background = element_blank(), axis.title = element_text(size = (8)), plot.title = element_text(size = 8, face = "bold", hjust = 0.5), axis.text.x = element_blank(), axis.ticks.x = element_blank(), axis.text.y = element_blank(), axis.ticks.y = element_blank()) +
  stat_cor(aes(label = ..r.label..), label.x.npc = 0.4, label.y.npc = "bottom", method = "pearson", cor.coef.name = "r", r.accuracy = 0.01, size = 5.5)

#POICN - by year
p10 <- ggplot(YEARS, aes(launched, all)) +
  geom_jitter(colour = "green", size = 2, alpha = 0.2, width = 1) +
  ggtitle("Year (n=27)") +
  geom_smooth(method = lm, lty = 2, colour = "black", size = 0.5, se=FALSE) +
  xlab("Attacks") +
  ylab("Plots") +
  theme(axis.line = element_line(), panel.background = element_blank(), axis.title = element_text(size = (8)), plot.title = element_text(size = 8, face = "bold", hjust = 0.5), axis.text.x = element_blank(), axis.ticks.x = element_blank(), axis.text.y = element_blank(), axis.ticks.y = element_blank()) +
  stat_cor(aes(label = ..r.label..), label.x.npc = 0.4, label.y.npc = "bottom", method = "pearson", cor.coef.name = "r", r.accuracy = 0.01, size = 5.5)

#POICN - by country year
p11 <- ggplot(POICN, aes(launched, all)) +
  geom_jitter(colour = "green", size = 2, alpha = 0.2, width = 1) +
  ggtitle("Country year (n=5859)") +
  geom_smooth(method = lm, lty = 2, colour = "black", size = 0.5, se=FALSE) +
  xlab("Attacks") +
  ylab("Plots") +
  theme(axis.line = element_line(), panel.background = element_blank(), axis.title = element_text(size = (8)), plot.title = element_text(size = 8, face = "bold", hjust = 0.5), axis.text.x = element_blank(), axis.ticks.x = element_blank(), axis.text.y = element_blank(), axis.ticks.y = element_blank()) +
  stat_cor(aes(label = ..r.label..), label.x.npc = 0.4, label.y.npc = "bottom", method = "pearson", cor.coef.name = "r", r.accuracy = 0.01, size = 5.5)

#Combining the above to row of figures
figC <- ggarrange(p9, p10, p11, ncol = 4, nrow = 1)
figC <- annotate_figure(figC, left = text_grob("POICN      ", face = "bold", size = 11))

#Combining the three rows into grid
figure2 <- ggarrange(figA, figB, figC, ncol = 1, nrow = 3)

ggsave("figure2.jpg")


# *** FIGURE 2: Bivariate correlations by functional form ***

#*#NESSER

#Transforming variables
NESSER$percentagemuslims <- as.integer(NESSER$percentagemuslims)
NESSER$launched_sqr <- sqrt(NESSER$launched)
NESSER$all_sqr <- sqrt(NESSER$all)
NESSER$launched_incrlog <- log(NESSER$launched + 1)
NESSER$all_incrlog <- log(NESSER$all + 1)
NESSER$launched_invsine <- asinh(NESSER$launched)
NESSER$all_invsine <- asinh(NESSER$all)
NESSER$launched_percap <- NESSER$launched / (NESSER$population * NESSER$percentagemuslims / 100000)
NESSER$all_percap <-  NESSER$all / (NESSER$population * NESSER$percentagemuslims / 100000)

#Nesser - square root transformation
p18 <- ggplot(NESSER, aes(launched_sqr, all_sqr)) +
  geom_point(colour = "magenta", size = 2, position = "jitter", alpha = 0.3) +
  ggtitle("Square root") +
  geom_smooth(method = lm, lty = 2, colour = "black", size = 0.5, se=FALSE) +
  xlab("Attacks (sqrt)") +
  ylab("Plots (sqrt)") +
  theme(axis.line = element_line(), panel.background = element_blank(), axis.title = element_text(size = (8)), plot.title = element_text(size = 8, face = "bold", hjust = 0.5), axis.text.x = element_blank(), axis.ticks.x = element_blank(), axis.text.y = element_blank(), axis.ticks.y = element_blank()) +
  stat_cor(aes(label = ..r.label..), label.x.npc = 0.4, label.y.npc = "bottom", method = "pearson", cor.coef.name = "r", r.accuracy = 0.01, size = 5.5)

#Nesser - increment and log transformation
p19 <- ggplot(NESSER, aes(launched_incrlog, all_incrlog)) +
  geom_point(colour = "magenta", size = 2, position = "jitter", alpha = 0.3) +
  ggtitle("Increment and log") +
  geom_smooth(method = lm, lty = 2, colour = "black", size = 0.5, se=FALSE) +
  xlab("Log (attacks + 1)") +
  ylab("Log (plots +1)") +
  theme(axis.line = element_line(), panel.background = element_blank(), axis.title = element_text(size = (8)), plot.title = element_text(size = 8, face = "bold", hjust = 0.5), axis.text.x = element_blank(), axis.ticks.x = element_blank(), axis.text.y = element_blank(), axis.ticks.y = element_blank()) +
  stat_cor(aes(label = ..r.label..), label.x.npc = 0.4, label.y.npc = "bottom", method = "pearson", cor.coef.name = "r", r.accuracy = 0.01, size = 5.5)

#Nesser - inverse hyperbolic sine transformation
p20 <- ggplot(NESSER, aes(launched_invsine, all_invsine)) +
  geom_point(colour = "magenta", size = 2, position = "jitter", alpha = 0.3) +
  ggtitle("Inverse hyperbolic sine") +
  geom_smooth(method = lm, lty = 2, colour = "black", size = 0.5, se=FALSE) +
  xlab("Attacks (asinh)") +
  ylab("Plots (asinh)") +
  theme(axis.line = element_line(), panel.background = element_blank(), axis.title = element_text(size = (8)), plot.title = element_text(size = 8, face = "bold", hjust = 0.5), axis.text.x = element_blank(), axis.ticks.x = element_blank(), axis.text.y = element_blank(), axis.ticks.y = element_blank()) +
  stat_cor(aes(label = ..r.label..), label.x.npc = 0.4, label.y.npc = "bottom", method = "pearson", cor.coef.name = "r", r.accuracy = 0.01, size = 5.5)

#Nesser - per capita adjustment
p21 <- ggplot(NESSER, aes(launched_percap, all_percap)) +
  geom_point(colour = "magenta", size = 2, position = "jitter", alpha = 0.3) +
  ggtitle("Per capita rate") +
  geom_smooth(method = lm, lty = 2, colour = "black", size = 0.5, se=FALSE) +
  xlab("Attacks per 1000 Muslims") +
  ylab("Plots per 1000 Muslims") +
  theme(axis.line = element_line(), panel.background = element_blank(), axis.title = element_text(size = (8)), plot.title = element_text(size = 8, face = "bold", hjust = 0.5), axis.text.x = element_blank(), axis.ticks.x = element_blank(), axis.text.y = element_blank(), axis.ticks.y = element_blank()) +
  stat_cor(aes(label = ..r.label..), label.x.npc = 0.4, label.y.npc = "bottom", method = "pearson", cor.coef.name = "r", r.accuracy = 0.01, size = 5.5)

#Combining the above to a row of figures
figD <- ggarrange(p18, p19, p20, p21, ncol = 4, nrow = 1)
figD <- annotate_figure(figD, left = text_grob("Nesser     ", face = "bold", size = 11))

#CRENSHAW

#Transforming variables
CREN$launched_sqr <- sqrt(CREN$launched)
CREN$all_sqr <- sqrt(CREN$all)
CREN$launched_incrlog <- log(CREN$launched + 1)
CREN$all_incrlog <- log(CREN$all + 1)
CREN$launched_invsine <- asinh(CREN$launched)
CREN$all_invsine <- asinh(CREN$all)
CREN$percentagemuslims <- as.numeric(CREN$percentagemuslims)
CREN$launched_percap <- CREN$launched / (CREN$population * CREN$percentagemuslims / 100000)
CREN$all_percap <-  CREN$all / (CREN$population * CREN$percentagemuslims / 100000)

#Crenshaw - square root transformation
p22 <- ggplot(CREN, aes(launched_sqr, all_sqr)) +
  geom_point(colour = "dodgerblue", size = 2, position = "jitter", alpha = 0.3) +
  ggtitle("Square root") +
  geom_smooth(method = lm, lty = 2, colour = "black", size = 0.5, se=FALSE) +
  xlab("Attacks (sqrt)") +
  ylab("Plots (sqrt)") +
  theme(axis.line = element_line(), panel.background = element_blank(), axis.title = element_text(size = (8)), plot.title = element_text(size = 8, face = "bold", hjust = 0.5), axis.text.x = element_blank(), axis.ticks.x = element_blank(), axis.text.y = element_blank(), axis.ticks.y = element_blank()) +
  stat_cor(aes(label = ..r.label..), label.x.npc = 0.4, label.y.npc = "bottom", method = "pearson", cor.coef.name = "r", r.accuracy = 0.01, size = 5.5)

#Crenshaw - increment and log transformation
p23 <- ggplot(CREN, aes(launched_incrlog, all_incrlog)) +
  geom_point(colour = "dodgerblue", size = 2, position = "jitter", alpha = 0.3) +
  ggtitle("Increment and log") +
  geom_smooth(method = lm, lty = 2, colour = "black", size = 0.5, se=FALSE) +
  xlab("Log (attacks + 1)") +
  ylab("Log (plots +1)") +
  theme(axis.line = element_line(), panel.background = element_blank(), axis.title = element_text(size = (8)), plot.title = element_text(size = 8, face = "bold", hjust = 0.5), axis.text.x = element_blank(), axis.ticks.x = element_blank(), axis.text.y = element_blank(), axis.ticks.y = element_blank()) +
  stat_cor(aes(label = ..r.label..), label.x.npc = 0.4, label.y.npc = "bottom", method = "pearson", cor.coef.name = "r", r.accuracy = 0.01, size = 5.5)

#Crenshaw - inverse hyperbolic sine transformation
p24 <- ggplot(CREN, aes(launched_invsine, all_invsine)) +
  geom_point(colour = "dodgerblue", size = 2, position = "jitter", alpha = 0.3) +
  ggtitle("Inverse hyperbolic sine") +
  geom_smooth(method = lm, lty = 2, colour = "black", size = 0.5, se=FALSE) +
  xlab("Attacks (asinh)") +
  ylab("Plots (asinh)") +
  theme(axis.line = element_line(), panel.background = element_blank(), axis.title = element_text(size = (8)), plot.title = element_text(size = 8, face = "bold", hjust = 0.5), axis.text.x = element_blank(), axis.ticks.x = element_blank(), axis.text.y = element_blank(), axis.ticks.y = element_blank()) +
  stat_cor(aes(label = ..r.label..), label.x.npc = 0.4, label.y.npc = "bottom", method = "pearson", cor.coef.name = "r", r.accuracy = 0.01, size = 5.5)

#Crenshaw - per capita adjustment
p25 <- ggplot(CREN, aes(launched_percap, all_percap)) +
  geom_point(colour = "dodgerblue", size = 2, position = "jitter", alpha = 0.3) +
  ggtitle("Per capita rate") +
  geom_smooth(method = lm, lty = 2, colour = "black", size = 0.5, se=FALSE) +
  xlab("Attacks per 1000 Muslims") +
  ylab("Plots per 1000 Muslims") +
  theme(axis.line = element_line(), panel.background = element_blank(), axis.title = element_text(size = (8)), plot.title = element_text(size = 8, face = "bold", hjust = 0.5), axis.text.x = element_blank(), axis.ticks.x = element_blank(), axis.text.y = element_blank(), axis.ticks.y = element_blank()) +
  stat_cor(aes(label = ..r.label..), label.x.npc = 0.4, label.y.npc = "bottom", method = "pearson", cor.coef.name = "r", r.accuracy = 0.01, size = 5.5)

#Combining the above to a row of figures
figE <- ggarrange(p22, p23, p24, p25, ncol = 4, nrow = 1)
figE <- annotate_figure(figE, left = text_grob("Crenshaw", face = "bold", size = 11))

# POICN

#Transforming variables
POICN$all <- POICN$launched + POICN$foiled
POICN$launched_sqr <- sqrt(POICN$launched)
POICN$all_sqr <- sqrt(POICN$all)
POICN$launched_incrlog <- log(POICN$launched + 1)
POICN$all_incrlog <- log(POICN$all + 1)
POICN$launched_invsine <- asinh(POICN$launched)
POICN$all_invsine <- asinh(POICN$all)
POICN$launched_percap <- POICN$launched / (POICN$population / 1000)
POICN$all_percap <-  POICN$all / (POICN$population / 1000)

#POICN - square root transformation
p26 <- ggplot(POICN, aes(launched_sqr, all_sqr)) +
  geom_point(colour = "green", size = 2, position = "jitter", alpha = 0.2) +
  ggtitle("Square root") +
  geom_smooth(method = lm, lty = 2, colour = "black", size = 0.5, se=FALSE) +
  xlab("Attacks (sqrt)") +
  ylab("Plots (sqrt)") +
  theme(axis.line = element_line(), panel.background = element_blank(), axis.title = element_text(size = (8)), plot.title = element_text(size = 8, face = "bold", hjust = 0.5), axis.text.x = element_blank(), axis.ticks.x = element_blank(), axis.text.y = element_blank(), axis.ticks.y = element_blank()) +
  stat_cor(aes(label = ..r.label..), label.x.npc = 0.4, label.y.npc = "bottom", method = "pearson", cor.coef.name = "r", r.accuracy = 0.01, size = 5.5)

#POICN - increment and log transformation
p27 <- ggplot(POICN, aes(launched_incrlog, all_incrlog)) +
  geom_point(colour = "green", size = 2, position = "jitter", alpha = 0.2) +
  ggtitle("Increment and log") +
  geom_smooth(method = lm, lty = 2, colour = "black", size = 0.5, se=FALSE) +
  xlab("Log (attacks + 1)") +
  ylab("Log (plots +1)") +
  theme(axis.line = element_line(), panel.background = element_blank(), axis.title = element_text(size = (8)), plot.title = element_text(size = 8, face = "bold", hjust = 0.5), axis.text.x = element_blank(), axis.ticks.x = element_blank(), axis.text.y = element_blank(), axis.ticks.y = element_blank()) +
  stat_cor(aes(label = ..r.label..), label.x.npc = 0.4, label.y.npc = "bottom", method = "pearson", cor.coef.name = "r", r.accuracy = 0.01, size = 5.5)

#POICN - inverse hyperbolic sine transformation
p28 <- ggplot(POICN, aes(launched_invsine, all_invsine)) +
  geom_point(colour = "green", size = 2, position = "jitter", alpha = 0.2) +
  ggtitle("Inverse hyperbolic sine") +
  geom_smooth(method = lm, lty = 2, colour = "black", size = 0.5, se=FALSE) +
  xlab("Attacks (asinh)") +
  ylab("Plots (asinh)") +
  theme(axis.line = element_line(), panel.background = element_blank(), axis.title = element_text(size = (8)), plot.title = element_text(size = 8, face = "bold", hjust = 0.5), axis.text.x = element_blank(), axis.ticks.x = element_blank(), axis.text.y = element_blank(), axis.ticks.y = element_blank()) +
  stat_cor(aes(label = ..r.label..), label.x.npc = 0.4, label.y.npc = "bottom", method = "pearson", cor.coef.name = "r", r.accuracy = 0.01, size = 5.5)

#POICN - per capita adjustment
p29 <- ggplot(POICN, aes(launched_percap, all_percap)) +
  geom_point(colour = "green", size = 2, position = "jitter", alpha = 0.2) +
  ggtitle("Per capita rate") +
  geom_smooth(method = lm, lty = 2, colour = "black", size = 0.5, se=FALSE) +
  xlab("Attacks per 1000 inhabitants") +
  ylab("Plots per 1000 inhabitants") +
  theme(axis.line = element_line(), panel.background = element_blank(), axis.title = element_text(size = (8)), plot.title = element_text(size = 8, face = "bold", hjust = 0.5), axis.text.x = element_blank(), axis.ticks.x = element_blank(), axis.text.y = element_blank(), axis.ticks.y = element_blank()) +
  stat_cor(aes(label = ..r.label..), label.x.npc = 0.4, label.y.npc = "bottom", method = "pearson", cor.coef.name = "r", r.accuracy = 0.01, size = 5.5)

#Combining the above to a row of figures
figF <- ggarrange(p26, p27, p28, p29, ncol = 4, nrow = 1)
figF <- annotate_figure(figF, left = text_grob("POICN      ", face = "bold", size = 11))

#Combining the rows into a grid
figure3 <- ggarrange(figD, figE, figF, ncol = 1, nrow = 3)

ggsave("figure3.jpg")


# *** Figure 4: Poisson and negative binomial distributions of expected counts (overlaid bars) ***

#Preparing the dataframes for the barplots


#Nesser
a <- data.frame(percent.table(NESSER$all_poisson), "var" = "all")
newrows <- data.frame(c("4","5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20"), c("0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0"), c("all", "all", "all", "all", "all", "all", "all", "all", "all", "all", "all", "all", "all", "all", "all", "all", "all"))
names(newrows) <- c("x", "Freq", "var")
a <- rbind(a, newrows)
b <- data.frame(percent.table(NESSER$launched_poisson), "var" = "launched")
NPOIS <- rbind(a, b)
NPOIS$Freq <- as.numeric(NPOIS$Freq)
NPOIS$x <- as.integer(NPOIS$x)

g <- data.frame(percent.table(NESSER$nb_all), "var" = "all")
newrows <- data.frame(c("7", "8", "9", "10", "11", "12"), c("0", "0", "0", "0", "0", "0"), c("all", "all", "all", "all", "all", "all"))
names(newrows) <- c("x", "Freq", "var")
g <- rbind(g, newrows)
X <- c("0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13")
g <- g %>% slice(match(X, x))
newrows <- data.frame(c("14", "15", "16", "17", "18", "19", "20"), c("0", "0", "0", "0", "0", "0", "0"), c("all", "all", "all", "all", "all", "all", "all"))
names(newrows) <- c("x", "Freq", "var")
g <- rbind(g, newrows)

h <- data.frame(percent.table(NESSER$nb_launched), "var" = "launched")
newrows <- data.frame(c("5", "6", "7", "8", "9"), c("0", "0", "0", "0", "0"), c("launched", "launched", "launched", "launched", "launched"))
names(newrows) <- c("x", "Freq", "var")
h <- rbind(h, newrows)
X <- c("0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10")
h <- h %>% slice(match(X, x))
NNB <- rbind(g, h)
NNB$Freq <- as.numeric(NNB$Freq)
NNB$x <- as.integer(NNB$x)

#Crenshaw
c <- data.frame(percent.table(CREN$all_poisson), "var" = "all")
newrows <- data.frame(c("5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20"), c("0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0"), c("all", "all", "all", "all", "all", "all", "all", "all", "all", "all", "all", "all", "all", "all", "all", "all"))
names(newrows) <- c("x", "Freq", "var")
c <- rbind(c, newrows)

d <- data.frame(percent.table(CREN$launched_poisson), "var" = "launched")
CPOIS <- rbind(c, d)
CPOIS$Freq <- as.numeric(CPOIS$Freq)
CPOIS$x <- as.integer(CPOIS$x)

i <- data.frame(percent.table(CREN$nb_all), "var" = "all")
newrows <- data.frame(c("9", "10", "11", "13", "16", "17", "18", "19"), c("0", "0", "0", "0", "0", "0", "0", "0"), c("all", "all", "all", "all", "all", "all", "all", "all"))
names(newrows) <- c("x", "Freq", "var")
i <- rbind(i, newrows)
X <- c("0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20")
i <- i %>% slice(match(X, x))

j <- data.frame(percent.table(CREN$nb_launched), "var" = "launched")
newrows <- data.frame(c("5", "6", "7", "8", "9", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20"), c("0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0"), c("launched", "launched", "launched", "launched", "launched", "launched", "launched", "launched", "launched", "launched", "launched", "launched", "launched", "launched", "launched"))
names(newrows) <- c("x", "Freq", "var")
j <- rbind(j, newrows)
X <- c("0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20" )
j <- j %>% slice(match(X, x))
CNB <- rbind(i, j)
CNB$Freq <- as.numeric(CNB$Freq)
CNB$x <- as.integer(CNB$x)

#POICN

e <- data.frame(percent.table(POICN$all_poisson), "var" = "all")
newrows <- data.frame(c("3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20"), c("0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0"), c("all", "all", "all", "all", "all", "all", "all", "all", "all", "all", "all", "all", "all", "all", "all", "all", "all", "all"))
names(newrows) <- c("x", "Freq", "var")
e <- rbind(e, newrows)
f <- data.frame(percent.table(POICN$launched_poisson), "var" = "launched")
PPOIS <- rbind(e, f)
PPOIS$Freq <- as.numeric(PPOIS$Freq)
PPOIS$x <- as.integer(PPOIS$x)

k <- data.frame(percent.table(POICN$all_nb), "var" = "all")
newrows <- data.frame(c("9", "10", "14", "15", "16", "17", "18", "19", "20"), c("0", "0","0", "0", "0", "0", "0", "0", "0"), c("all", "all", "all", "all", "all", "all", "all", "all", "all"))
names(newrows) <- c("x", "Freq", "var")
k <- rbind(k, newrows)
X <- c("0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20" )
k <- k %>% slice(match(X, x))

l <- data.frame(percent.table(POICN$launched_nb), "var" = "launched")

PNB <- rbind(k, l)
PNB$Freq <- as.numeric(PNB$Freq)
PNB$x <- as.integer(PNB$x)

#NESSER

#Nesser - poisson distribution
p30 <- ggplot(NPOIS, aes(x = x, y = Freq, fill=var)) + 
  geom_bar(stat = "identity", width = 1, position="identity", alpha = 0.7, colour="black", size=0.2) +
  ggtitle("Poisson") +
  xlab("") + ylab("") +
  theme_classic() +
  theme(legend.position = "none", plot.title = element_text(size = 11, face = "bold", hjust = 0.5)) +
  scale_y_continuous(limits = c(0, 100), expand = c(0,0)) +
  scale_x_continuous(expand = c(0,0), breaks = c(0, 10, 20)) +
  scale_fill_manual(values=c("magenta", "thistle2"))

#Nesser - negative binomial                      
p31 <- ggplot(NNB, aes(x = x, y = Freq, fill=var)) + 
  geom_bar(stat = "identity", width = 1, position="identity", alpha = 0.7, colour="black", size=0.2) +
  ggtitle("Negative binomial") +
  xlab("") + ylab("") +
  theme_classic() +
  theme(legend.position = c(0.65, 0.5), plot.title = element_text(size = 11, face = "bold", hjust = 0.5)) +
  scale_y_continuous(limits = c(0, 100), expand = c(0,0)) +
  scale_x_continuous(expand = c(0,0), breaks = c(0, 10, 20)) +
  scale_fill_manual(values=c("magenta", "thistle2"), name = "", labels = c("Plots\n      mean = 0.44\n      dispersion = 4.82", "Attacks\n      mean = 0.19\n      dispersion = 11.11"))

#Combining the above to a row of figures
figA <- ggarrange(p30, p31, ncol = 2, nrow = 1)
figA <- annotate_figure(figA, left = text_grob("Nesser     ", face = "bold", size = 11))

#Crenshaw - poisson distribution
p32 <- ggplot(CPOIS, aes(x = x, y = Freq, fill=var)) + 
  geom_bar(stat="identity", width = 1, position="identity", alpha = 0.7, colour="black", size=0.2) +
  theme_classic() +
  xlab("") + ylab("Percent") + 
  theme(legend.position = "none") +
  scale_y_continuous(limits = c(0, 100), expand = c(0,0)) +
  scale_x_continuous(expand = c(0,0), breaks = c(0, 10, 20)) +
  scale_fill_manual(values=c("blue", "lightskyblue1"))

#Crenshaw - negative binomial
p33 <- ggplot(CNB, aes(x = x, y = Freq, fill=var)) + 
  geom_bar(stat="identity", width = 1, position="identity", alpha = 0.7, colour="black", size=0.2) +
  theme_classic() +
  xlab("") + ylab("") + 
  theme(legend.position = c(0.65, 0.5)) +
  scale_y_continuous(limits = c(0, 100), expand = c(0,0)) +
  scale_x_continuous(expand = c(0,0), breaks = c(0, 10, 20)) +
  scale_fill_manual(values=c("blue", "lightskyblue1"), name = "", labels = c("Plots\n      mean = 0.66\n      dispersion = 6.63", "Attacks\n      mean = 0.21\n      dispersion =  11.12"))

#Combining the above to a row of figures
figB <- ggarrange(p32, p33, ncol = 2, nrow = 1)
figB <- annotate_figure(figB, left = text_grob("Crenshaw", face = "bold", size = 11))

#POICN - poisson distribution
p34 <- ggplot(PPOIS, aes(x = x, y = Freq, fill=var)) + 
  geom_bar(stat="identity", width = 1, position="identity", alpha = 0.7, colour="black", size=0.2) +
  theme_classic() +
  xlab("") + ylab("") +
  theme(legend.position = "none") +
  scale_y_continuous(limits = c(0, 100), expand = c(0,0)) +
  scale_x_continuous(expand = c(0,0), breaks = c(0, 10, 20)) +
  scale_fill_manual(values=c("green4", "palegreen"))

#POICN - negative binomial
p35 <- ggplot(PNB, aes(x = x, y = Freq, fill=var)) + 
  geom_bar(stat="identity", width = 1, position="identity", alpha = 0.7, colour="black", size=0.2) +
  theme_classic() +
  xlab("") + ylab("") +
  theme(legend.position = c(0.65, 0.5)) +
  scale_y_continuous(limits = c(0, 100), expand = c(0,0)) +
  scale_x_continuous(expand = c(0,0), breaks = c(0, 10, 20)) +
  scale_fill_manual(values=c("green4", "palegreen"), name = "", labels = c("Plots\n      mean = 0.08\n      dispersion = 33.18", "Attacks\n      mean = 0.04\n      dispersion = 82.48"))

#Combining the above to a row of figures
figC <- ggarrange(p34, p35, ncol = 2, nrow = 1)
figC <- annotate_figure(figC, left = text_grob("POICN      ", face = "bold", size = 11), bottom = text_grob("k", face = "italic", size = 11))

#Combining the rows into a grid
figure4 <- ggarrange(figA, figB, figC, ncol = 1, nrow = 3)

ggsave("figure4.jpg")



# *** CSV files with transformed variables for use in "replication_tables.do" ***

#First: Nesser dataset

NESSER$unemployment <- as.numeric(NESSER$unemployment)

#lags
NESSER <- slide(NESSER, Var = "all", GroupVar = "country", NewVar = "l_all", slideBy = -1)
NESSER <- slide(NESSER, Var = "launched", GroupVar = "country", NewVar = "l_launched", slideBy = -1)
NESSER <- slide(NESSER, Var = "population", GroupVar = "country", NewVar = "l_population", slideBy = -1)
NESSER <- slide(NESSER, Var = "gdpcap", GroupVar = "country", NewVar = "l_gdpcap", slideBy = -1)
NESSER <- slide(NESSER, Var = "refugees", GroupVar = "country", NewVar = "l_refugees", slideBy = -1)
NESSER <- slide(NESSER, Var = "rightwingness", GroupVar = "country", NewVar = "l_rightwingness", slideBy = -1)
NESSER <- slide(NESSER, Var = "cpi", GroupVar = "country", NewVar = "l_cpi", slideBy = -1)
NESSER <- slide(NESSER, Var = "percentagemuslims", GroupVar = "country", NewVar = "l_percentagemuslims", slideBy = -1)
NESSER <- slide(NESSER, Var = "unemployment", GroupVar = "country", NewVar = "l_unemployment", slideBy = -1)
NESSER <- slide(NESSER, Var = "socialspend", GroupVar = "country", NewVar = "l_socialspend", slideBy = -1)
NESSER <- slide(NESSER, Var = "troops_in_mw", GroupVar = "country", NewVar = "l_troops_in_mw", slideBy = -1)
NESSER <- slide(NESSER, Var = "securityspend", GroupVar = "country", NewVar = "l_securityspend", slideBy = -1)
NESSER <- slide(NESSER, Var = "elections", GroupVar = "country", NewVar = "l_elections", slideBy = -1)
NESSER <- slide(NESSER, Var = "rwattacks", GroupVar = "country", NewVar = "l_rwattacks", slideBy = -1)

#Transformations
NESSER$as_all <- asinh(NESSER$all)
NESSER$as_launched <- asinh(NESSER$launched)
NESSER$asl_all <- asinh(NESSER$l_all)
NESSER$asl_launched <- asinh(NESSER$l_launched)
NESSER$ll_population <- log(NESSER$l_population)
NESSER$ll_gdpcap <- log(NESSER$l_gdpcap)
NESSER$ll_refugees <- log(NESSER$l_refugees)
NESSER$ll_rightwingness <- log(NESSER$l_rightwingness)
NESSER$cpichg <- 100*(NESSER$cpi - NESSER$l_cpi) / NESSER$l_cpi 
NESSER$asl_troops_in_mw <- asinh(NESSER$l_troops_in_mw)
NESSER$sql_rwattacks <- sqrt(NESSER$l_rwattacks)
NESSER <- NESSER %>% mutate(years_from_2001 = ifelse(year > 2001, year-2001, 0))
NESSER$years_from_2001_sq <- NESSER$years_from_2001^2
NESSER <- NESSER %>% mutate(years_from_isis = ifelse(year > 2015, year-2015, 0))
NESSER$years_from_isis_sq <- NESSER$years_from_isis^2
NESSER <- slide(NESSER, Var = "cpichg", GroupVar = "country", NewVar = "l_cpichg", slideBy = -1)

write.csv(NESSER, "Nesser_transformations.csv")

#Next: Crenshaw dataset

CREN$unemployment <- as.numeric(CREN$unemployment)

#lags
CREN <- slide(CREN, Var = "all", GroupVar = "country", NewVar = "l_all", slideBy = -1)
CREN <- slide(CREN, Var = "launched", GroupVar = "country", NewVar = "l_launched", slideBy = -1)
CREN <- slide(CREN, Var = "population", GroupVar = "country", NewVar = "l_population", slideBy = -1)
CREN <- slide(CREN, Var = "gdpcap", GroupVar = "country", NewVar = "l_gdpcap", slideBy = -1)
CREN <- slide(CREN, Var = "refugees", GroupVar = "country", NewVar = "l_refugees", slideBy = -1)
CREN <- slide(CREN, Var = "rightwingness", GroupVar = "country", NewVar = "l_rightwingness", slideBy = -1)
CREN <- slide(CREN, Var = "cpi", GroupVar = "country", NewVar = "l_cpi", slideBy = -1)
CREN <- slide(CREN, Var = "percentagemuslims", GroupVar = "country", NewVar = "l_percentagemuslims", slideBy = -1)
CREN <- slide(CREN, Var = "unemployment", GroupVar = "country", NewVar = "l_unemployment", slideBy = -1)
CREN <- slide(CREN, Var = "socialspend", GroupVar = "country", NewVar = "l_socialspend", slideBy = -1)
CREN <- slide(CREN, Var = "troops_in_mw", GroupVar = "country", NewVar = "l_troops_in_mw", slideBy = -1)
CREN <- slide(CREN, Var = "securityspend", GroupVar = "country", NewVar = "l_securityspend", slideBy = -1)
CREN <- slide(CREN, Var = "elections", GroupVar = "country", NewVar = "l_elections", slideBy = -1)
CREN <- slide(CREN, Var = "rwattacks", GroupVar = "country", NewVar = "l_rwattacks", slideBy = -1)

#Transformation
CREN$as_all <- asinh(CREN$all)
CREN$as_launched <- asinh(CREN$launched)
CREN$asl_all <- asinh(CREN$l_all)
CREN$asl_launched <- asinh(CREN$l_launched)
CREN$ll_population <- log(CREN$l_population)
CREN$ll_gdpcap <- log(CREN$l_gdpcap)
CREN$ll_refugees <- log(CREN$l_refugees)
CREN$ll_rightwingness <- log(CREN$l_rightwingness)
CREN$cpichg <- 100*(CREN$cpi - CREN$l_cpi) / CREN$l_cpi 
CREN$asl_troops_in_mw <- asinh(CREN$l_troops_in_mw)
CREN$sql_rwattacks <- sqrt(CREN$l_rwattacks)
CREN <- CREN %>% mutate(years_from_2001 = ifelse(year > 2001, year-2001, 0))
CREN$years_from_2001_sq <- CREN$years_from_2001^2
CREN <- CREN %>% mutate(years_from_isis = ifelse(year > 2015, year-2015, 0))
CREN$years_from_isis_sq <- CREN$years_from_isis^2
CREN <- slide(CREN, Var = "cpichg", GroupVar = "country", NewVar = "l_cpichg", slideBy = -1)

write.csv(CREN, "Crenshaw_transformations.csv")