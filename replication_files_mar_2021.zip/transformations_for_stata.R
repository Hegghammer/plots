# This script is part of the replication material for the manuscript "Measuring Terrorism"
# It produces the figures in the main manuscript plus two new csv files for use in
# the Stata script "replication_tables.do", which accompanies this file.

library(dplyr)
library(DataCombine)

NESSER <- read.csv("Nesser.csv", sep=",")
CREN <- read.csv("Crenshaw.csv", sep=",")
POICN <- read.csv("POICN.csv", sep=",")

# Create CSV files with transformed variables for use in "replication_tables.do"

#First: Nesser dataset

# lags
NESSER <- slide(NESSER, Var = "all", GroupVar = "country", NewVar = "l_all", slideBy = -1)
NESSER <- slide(NESSER, Var = "launched", GroupVar = "country", NewVar = "l_launched", slideBy = -1)
NESSER <- slide(NESSER, Var = "population", GroupVar = "country", NewVar = "l_population", slideBy = -1)
NESSER <- slide(NESSER, Var = "gdpcap", GroupVar = "country", NewVar = "l_gdpcap", slideBy = -1)
NESSER <- slide(NESSER, Var = "refugees", GroupVar = "country", NewVar = "l_refugees", slideBy = -1)
NESSER <- slide(NESSER, Var = "rightwingness", GroupVar = "country", NewVar = "l_rightwingness", slideBy = -1)
NESSER <- slide(NESSER, Var = "cpi", GroupVar = "country", NewVar = "l_cpi", slideBy = -1)
NESSER <- slide(NESSER, Var = "percentagemuslims", GroupVar = "country", NewVar = "l_percentagemuslims", slideBy = -1)
NESSER <- slide(NESSER, Var = "unemployment", GroupVar = "country", NewVar = "l_unemployment", slideBy = -1)
NESSER <- slide(NESSER, Var = "socialspend", GroupVar = "country", NewVar = "l_socialspend", slideBy = -1)
NESSER <- slide(NESSER, Var = "troops_in_mw", GroupVar = "country", NewVar = "l_troops_in_mw", slideBy = -1)
NESSER <- slide(NESSER, Var = "securityspend", GroupVar = "country", NewVar = "l_securityspend", slideBy = -1)
NESSER <- slide(NESSER, Var = "rwattacks", GroupVar = "country", NewVar = "l_rwattacks", slideBy = -1)

# Transformations
NESSER$as_all <- asinh(NESSER$all)
NESSER$as_launched <- asinh(NESSER$launched)
NESSER$asl_all <- asinh(NESSER$l_all)
NESSER$asl_launched <- asinh(NESSER$l_launched)
NESSER$ll_population <- log(NESSER$l_population)
NESSER$ll_gdpcap <- log(NESSER$l_gdpcap)
NESSER$ll_refugees <- log(NESSER$l_refugees)
NESSER$ll_rightwingness <- log(NESSER$l_rightwingness)
NESSER$cpichg <- 100*(NESSER$cpi - NESSER$l_cpi) / NESSER$l_cpi
NESSER$asl_troops_in_mw <- asinh(NESSER$l_troops_in_mw)
NESSER$sql_rwattacks <- sqrt(NESSER$l_rwattacks)
NESSER <- NESSER %>% mutate(years_from_2001 = ifelse(year > 2001, year-2001, 0))
NESSER$years_from_2001_sq <- NESSER$years_from_2001^2
NESSER <- NESSER %>% mutate(years_from_isis = ifelse(year > 2014, year-2014, 0))
NESSER$years_from_isis_sq <- NESSER$years_from_isis^2
NESSER <- slide(NESSER, Var = "cpichg", GroupVar = "country", NewVar = "l_cpichg", slideBy = -1)

write.csv(NESSER, "Nesser_transformations.csv", row.names = FALSE)

# Next: Crenshaw dataset

# lags
CREN <- slide(CREN, Var = "all", GroupVar = "country", NewVar = "l_all", slideBy = -1)
CREN <- slide(CREN, Var = "launched", GroupVar = "country", NewVar = "l_launched", slideBy = -1)
CREN <- slide(CREN, Var = "population", GroupVar = "country", NewVar = "l_population", slideBy = -1)
CREN <- slide(CREN, Var = "gdpcap", GroupVar = "country", NewVar = "l_gdpcap", slideBy = -1)
CREN <- slide(CREN, Var = "refugees", GroupVar = "country", NewVar = "l_refugees", slideBy = -1)
CREN <- slide(CREN, Var = "rightwingness", GroupVar = "country", NewVar = "l_rightwingness", slideBy = -1)
CREN <- slide(CREN, Var = "cpi", GroupVar = "country", NewVar = "l_cpi", slideBy = -1)
CREN <- slide(CREN, Var = "percentagemuslims", GroupVar = "country", NewVar = "l_percentagemuslims", slideBy = -1)
CREN <- slide(CREN, Var = "unemployment", GroupVar = "country", NewVar = "l_unemployment", slideBy = -1)
CREN <- slide(CREN, Var = "socialspend", GroupVar = "country", NewVar = "l_socialspend", slideBy = -1)
CREN <- slide(CREN, Var = "troops_in_mw", GroupVar = "country", NewVar = "l_troops_in_mw", slideBy = -1)
CREN <- slide(CREN, Var = "securityspend", GroupVar = "country", NewVar = "l_securityspend", slideBy = -1)
CREN <- slide(CREN, Var = "rwattacks", GroupVar = "country", NewVar = "l_rwattacks", slideBy = -1)

# Transformations
CREN$as_all <- asinh(CREN$all)
CREN$as_launched <- asinh(CREN$launched)
CREN$asl_all <- asinh(CREN$l_all)
CREN$asl_launched <- asinh(CREN$l_launched)
CREN$ll_population <- log(CREN$l_population)
CREN$ll_gdpcap <- log(CREN$l_gdpcap)
CREN$ll_refugees <- log(CREN$l_refugees)
CREN$ll_rightwingness <- log(CREN$l_rightwingness)
CREN$cpichg <- 100*(CREN$cpi - CREN$l_cpi) / CREN$l_cpi
CREN$asl_troops_in_mw <- asinh(CREN$l_troops_in_mw)
CREN$sql_rwattacks <- sqrt(CREN$l_rwattacks)
CREN <- CREN %>% mutate(years_from_2001 = ifelse(year > 2001, year-2001, 0))
CREN$years_from_2001_sq <- CREN$years_from_2001^2
CREN <- CREN %>% mutate(years_from_isis = ifelse(year > 2014, year-2014, 0))
CREN$years_from_isis_sq <- CREN$years_from_isis^2
CREN <- slide(CREN, Var = "cpichg", GroupVar = "country", NewVar = "l_cpichg", slideBy = -1)

write.csv(CREN, "Crenshaw_transformations.csv", row.names = FALSE)
